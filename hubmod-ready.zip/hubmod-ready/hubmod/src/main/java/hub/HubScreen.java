package hub;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HubScreen extends Screen {
    private static final int PANEL = 0xF0202225, ROW = 0xFF2B2E32, ROW_HOVER = 0xFF33373C;
    private static final int ACCENT = 0xFF5B8DEF, OFF = 0xFF4A4E54, TEXT = 0xFFE6E8EB, MUTED = 0xFF9AA0A6;
    private static final int W = 220, H = 100, ROW_H = 28;

    public HubScreen() { super(Text.literal("Hub")); }

    private int px() { return (width - W) / 2; }
    private int py() { return (height - H) / 2; }
    private boolean overRow(double mx, double my) {
        int x = px() + 12, y = py() + 44;
        return mx >= x && mx <= x + W - 24 && my >= y && my <= y + ROW_H;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, 0x66000000);
        int x = px(), y = py();
        c.fill(x, y, x + W, y + H, PANEL);
        c.drawText(textRenderer, "Hub", x + 12, y + 12, TEXT, false);
        c.drawText(textRenderer, "Visual", x + 12, y + 26, MUTED, false);

        int rx = x + 12, ry = y + 44, rw = W - 24;
        c.fill(rx, ry, rx + rw, ry + ROW_H, overRow(mx, my) ? ROW_HOVER : ROW);
        c.drawText(textRenderer, "Fullbright", rx + 10, ry + 10, TEXT, false);
        int sx = rx + rw - 38, sy = ry + 8;
        c.fill(sx, sy, sx + 28, sy + 12, HubMod.fullbright ? ACCENT : OFF);
        int kx = HubMod.fullbright ? sx + 16 : sx + 2;
        c.fill(kx, sy + 2, kx + 10, sy + 10, TEXT);

        c.drawText(textRenderer, "Esc - close", x + 12, y + H - 16, MUTED, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && overRow(mx, my)) {
            HubMod.fullbright = !HubMod.fullbright;
            HubMod.save();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }
}
