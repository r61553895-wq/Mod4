package hub;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class HubMod implements ClientModInitializer {
    public static boolean fullbright = false;
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("hubmod.properties");
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        load();
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hubmod.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.hubmod"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new HubScreen());
            }
        });
    }

    public static void load() {
        try (InputStream in = Files.newInputStream(FILE)) {
            Properties p = new Properties();
            p.load(in);
            fullbright = Boolean.parseBoolean(p.getProperty("fullbright", "false"));
        } catch (IOException | RuntimeException ignored) {}
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
        } catch (IOException ignored) {}
        try (OutputStream out = Files.newOutputStream(FILE)) {
            Properties p = new Properties();
            p.setProperty("fullbright", Boolean.toString(fullbright));
            p.store(out, "Hub");
        } catch (IOException | RuntimeException ignored) {}
    }
}
