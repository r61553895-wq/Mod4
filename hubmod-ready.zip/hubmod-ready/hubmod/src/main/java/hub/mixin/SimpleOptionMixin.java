package hub.mixin;

import hub.HubMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(SimpleOption.class)
public class SimpleOptionMixin {
    @Inject(method = "getValue", at = @At("HEAD"), cancellable = true)
    private void hub$fullbright(CallbackInfoReturnable<Object> cir) {
        if (!HubMod.fullbright) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc != null && mc.options != null && (Object) this == mc.options.getGamma()) {
            cir.setReturnValue(16.0D);
        }
    }
}
