# Hub Mod — Minecraft 1.21.4 / Fabric

This project is configured to build automatically with GitHub Actions.

## Automatic browser build
1. Upload the contents of this folder to a GitHub repository (the `.github/workflows/build.yml` file must be included).
2. Open the repository's **Actions** tab and select **Build Fabric Mod JAR**.
3. Open the latest successful run and download the `hubmod-jar` artifact.
4. Extract the artifact ZIP; the `.jar` inside is the mod file.

Requires Java 21 and Minecraft 1.21.4 with compatible Fabric Loader and Fabric API.

Important: a successful compile does not replace in-game testing. This project currently includes a small hub and Fullbright; Custom Time is not implemented.
